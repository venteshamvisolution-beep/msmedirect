<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Carbon\Carbon;
use App\Mail\ContactUsMail;
use App\Mail\ConnectionRequest;
use Mail;
use Session;
use Razorpay\Api\Api;
use App\Models\Pincode;
use App\Models\Coupons;
use Crypt;
use Auth;
use Str;
class HomeController extends Controller
{
    public function saveContactUs(Request $request){
        
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|regex:/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/',
            // 'company_name' => 'required|string|max:255',
            'mobile_number' => 'required|numeric|digits:10|regex:/^\d{10}$/',
            'message' => 'required|string',
        ]);
        
        $requestData = $request->all();
        $requestData['created_at'] = Carbon::now();
        unset($requestData['_token']);
        DB::table('contact_us')->insert($requestData);
        // Mail::to('vignesh.fiveonline@gmail.com')->send(new ContactUsMail($requestData));
        return back()->with('message', "Thank you for your message we'll get back to you shortly.");
    }
    
    public function msmeScheme(Request $request){
        $schemes = DB::table('schemes')->select('*','schemes_master.name as category_name')
                                        ->where('schemes_master.is_active',true)
                                        ->leftjoin('schemes_master','schemes_master.id','schemes.category_id');
                                        

        $schemeMaster = DB::table('schemes_master')->where('is_active',true)->pluck('name','id')->toArray();
        $param = $request->input('param');
        if($param != ''){
            $schemes = $schemes->where('schemes.category_id',$param);
        }
        $schemes = $schemes->get()->toArray();
        
        return view('info.scheme')->with('schemes',$schemes)->with('schemeMaster',$schemeMaster)->with('param',$param);
    }
    
    public function notifications(Request $request)
    {
        if(!Auth::check()){
            return redirect()->to('login');
        }
        // Auth::logout();
        
        $notifications = DB::table('front_notifications')->where('user_id',Auth::user()->id)->orderBy('id','desc')->get()->toArray();
        
        
        
         return view('notifications')->with('notifications',$notifications);
    
    }
    
     public function getPincodeData(Request $request)
    {
        $pincode = $request->input('pincode');

        // Validate pincode (you may add more validation rules as needed)
        $request->validate([
            'pincode' => 'required|numeric|digits:6',
        ]);

        // Find the Pincode data from the database
        $pincodeData = Pincode::where('Pincode', $pincode)->first();

        if ($pincodeData) {
            return response()->json([
                'city' => $pincodeData->City,
                'state' => $pincodeData->State,
            ]);
        } else {
            return response()->json(['error' => 'Pincode not found'], 404);
        }
    }
    
    protected function getConnectionCount($connId, $fromId)
    {
        return DB::table('connections')
            ->where('conn_id', $connId)
            ->where('from_id', $fromId)
            ->count();
    }
    
    protected function checkMsmeType_old($applicantEmail, $recipentId)
    {
        $applicantData = DB::table('user_data')->where('approve',true)
                                                    ->where('email',Auth::user()->email)->get()->toArray();
         
        $applicantData = (array) current($applicantData);
                                          
        $businessSize = json_decode($applicantData['business_size'],true);
        $recipentData = DB::table('user_data')->whereId($recipentId);
         
        $recipentData = $recipentData->where(function ($query) use ($businessSize) {
            foreach ($businessSize as $value) {
                $query->orWhereJsonContains('business_size', $value);
            }
        });
        
        $recipentData = $recipentData->get()->toArray();
        // dd($recipentId);       
        $returnArray = ['applicantArray'=>$applicantData,'recipentData'=>$recipentData];
        return $returnArray;
    }
    
    protected function checkMsmeType($applicantEmail, $recipentId)
    {
        $applicantData = DB::table('user_data')->where('approve',true)
                                                    ->where('email',Auth::user()->email)->get()->toArray();
                                                    
        // $connUserId = DB::table('user_data')->where('email',$applicantEmail)->value('id');
        $connUserId = $applicantData[0]->email;
        // dd($applicantData[0]->email);
        $applicantData = (array) current($applicantData);
                                          
        $businessSize = json_decode($applicantData['business_size'],true);
        $recipentData = DB::table('user_data')->whereId($connUserId);
         
        $recipentData = $recipentData->where(function ($query) use ($businessSize) {
            foreach ($businessSize as $value) {
                $query->orWhereJsonContains('business_size', $value);
            }
        });
        
        $recipentData = $recipentData->get()->toArray();
        // dd($recipentData);       
        $returnArray = ['applicantArray'=>$applicantData,'recipentData'=>$recipentData];
        return $returnArray;
    }
    
    protected function timeLineData($status){
        $timeline = [];
        $timeline[0]['status'] =  $status;
        $timeline[0]['created_at'] =  Carbon::now();
        return $timeline;
    }
    
    
    
    
    
    
    public function requestConnection(Request $request,$id){
        // dd($id);
        if(!Auth::check()){
            Session::put('requestConnectionMessage',$id);
            return redirect()->to('login');
        }
        
        $id = Crypt::decrypt($id);
        // dd($id);
        $email = DB::table('user_data')->where('user_data.id',$id)->value('email');
        $connUserId = DB::table('users')->where('email',$email)->value('id');
        $id = $connUserId;
        // dd($id);
        $userId = Auth::user()->id;
        $countDB = $this->getConnectionCount($id, $userId);
        $countConnDb = $this->getConnectionCount($userId, $id);
        if ($countConnDb >= 1 || $countDB >= 1) {
            return redirect()->back()->with('message','You have already been requested for connection');
        }
         
        // check if business size is similar to Auth
        $checkMsmeType = $this->checkMsmeType(Auth::user()->email,$id);
        if(count($checkMsmeType['recipentData']) < 1){
            $businessSize = json_decode($checkMsmeType['applicantArray']['business_size'],true);
            $message = 'Sorry, this MSME does not deal with '.implode(',',$businessSize);
            return redirect()->back()->with('message',$message);
        }
        // end of check if business size is similar to Auth
        
        $applicantData = $checkMsmeType['applicantArray'];
        $recipentData = (array) current($checkMsmeType['recipentData']);
        // echo "<pre>";print_r($applicantData);exit;
        
        $connectionData = [];
        $connectionData['conn_id'] = $connUserId;
        $connectionData['from_id'] = $userId;
        $connectionData['created_at'] = Carbon::now();
        $connectionData['status'] = 0;
        $connectionData['conn_user_data'] = $recipentData['id'];
        $connectionData['conn_business_type_id'] = $recipentData['business_type'];
        $connectionData['from_user_data'] = $applicantData['id'];
        $connectionData['from_business_type_id'] = $applicantData['business_type'];
        $timeline = $this->timeLineData('Connection Requested');
        $connectionData['timeline'] = json_encode($timeline);
        
        $connectionId = DB::table('connections')->insertGetId($connectionData);
        $connEncode = Crypt::encrypt('conn:'.$id.':'.$connectionId);
        $fromEncode = Crypt::encrypt('from:'.$userId.':'.$connectionId);
    
        DB::table('connections')->whereId($connectionId)->update(['conn_encode'=>$connEncode,'from_encode'=>$fromEncode]);
        
        
        $businessCategoryName = DB::table('business_category')->whereId($applicantData['business_category'])->value('name');
        
        $subBusinessCategoryName = DB::table('business_sub_category')->whereId($applicantData['business_sub_category'])->value('name');
        
        $notification = [];
        $notification['user_id'] = $connUserId;
        $notification['from_notification'] = $userId;
        $notification['conn_notification'] = $id;
        $notification['notification_id'] = 2;
        $notification['description'] = $businessCategoryName.' '.$subBusinessCategoryName.' has shown interest in your profile -:';
        $notification['link'] = route('userConnections');
        $notification['type'] = 'request_connection';
        $notification['is_mail'] = true;
        $notification['is_mail_sent'] = true;
        $notification['created_at'] = Carbon::now();
        DB::table('front_notifications')->insert($notification);
        
        $mailData = [];
        $mailData['name'] = $businessCategoryName.' '.$subBusinessCategoryName;
        $mailData['link'] = route('userConnections');
        Mail::to($recipentData['email'])->send(new ConnectionRequest($mailData));
        
        return redirect()->back()->with('message','Connection Request Processed');
       
    }
    
    
    
    
    public function userConnections(Request $request){
       
        if(!Auth::check()){
            return redirect()->to('login');
        }
        
      
        $connectionRequested = DB::table('connections')->select('connections.status','user_data.business_description','connections.from_encode','connections.created_at as connection_created_at','business_category.name as business_category_name','connections.from_id','connections.conn_id','connections.conn_encode')
                                                    ->leftjoin('users','users.id','connections.from_id')
                                                    ->leftjoin('user_data','user_data.email','users.email')
                                                    ->leftjoin('business_category','business_category.id','user_data.business_category')
                                                   ->where(function ($query) {
                                    $query->where('connections.from_id',Auth::user()->id)
                                          ->orWhere('connections.conn_id',Auth::user()->id);
                                })
                                            
                                                    // ->where('user_data.email',Auth::user()->email)
                                                    ->get()->toArray();
         
       
       $connectionRequest = DB::table('connections')->select('connections.status','user_data.business_description','connections.conn_encode','connections.created_at as connection_created_at','business_category.name as business_category_name')
                                                    ->leftjoin('users','users.id','connections.from_id')
                                                    ->leftjoin('user_data','user_data.email','users.email')
                                                    ->leftjoin('business_category','business_category.id','user_data.business_category')
                                                    ->where('connections.status',0)
                                                    ->where('connections.conn_id',Auth::user()->id)
                                                    ->get()->toArray();
                                                    
                                                    
        $msme_type = DB::table('user_data')->select('user_data.msme_type')
                                            ->where('user_data.id',Auth::user()->id)
                                            ->get()->first();
        return view('userConnections')->with('connectionRequests',$connectionRequested)->with('connectionAccept',$connectionRequest)->with('msme_type',$msme_type);
        
    }
    
    public static function sendNotification($connectionArray,$urlType="accept"){
        // $connectionArray = (array) current($connectionArray);
        
        $formUserData = DB::table('user_data')->select('business_sub_category.name as sub_category_name','business_category.name as business_category_name')->leftjoin('business_category','business_category.id','user_data.business_category')
        ->leftjoin('business_sub_category','business_sub_category.id','user_data.business_sub_category')->
            where('user_data.id',$connectionArray['from_user_data'])->get()->toArray();
        
        $fromUserData = (array) current($formUserData);
        
        
        
        
        $notification = [];
        // $url = url('/accept-connection/'.$connectionArray['from_encode']);
        $url = url("//user-connections");
        $notification['user_id'] = $connectionArray['from_id'];
        $notification['notification_id'] = 1;
        $notification['from_notification'] = $connectionArray['from_id'];
        $notification['conn_notification'] = $connectionArray['conn_id'];
        $notification['is_from_conn'] = 'from';
        $count = DB::table('front_notifications')->where($notification)->count();
        
        
        if($urlType == 'accept'){
            $notification['description'] = $fromUserData['business_category_name'].' '.$fromUserData['sub_category_name'].' this is your payment link -:';
            
        $notification['link'] = $url;
        $notification['type'] = 'payment_link';
        }else{
            
            $notification['description'] = $fromUserData['business_category_name'].' '.$fromUserData['sub_category_name'].' Declined';
        
        $notification['link'] = '';
        $notification['type'] = 'declined';
            
        }
        
        
        $notification['is_mail'] = true;
        $notification['is_mail_sent'] = false;
        $notification['created_at'] = Carbon::now();
        
        
        if($count == 0){
            DB::table('front_notifications')->insert($notification);
            
        }
        
        if($urlType == "declined"){
            return true;
        }
        
        
        $connUserData = DB::table('user_data')->select('business_sub_category.name as sub_category_name','business_category.name as business_category_name')->leftjoin('business_category','business_category.id','user_data.business_category')
        ->leftjoin('business_sub_category','business_sub_category.id','user_data.business_sub_category')->
            where('user_data.id',$connectionArray['conn_user_data'])->get()->toArray();
        
        $connUserData = (array) current($connUserData);
        
        
        $notification = [];
        // $url = url('/accept-connection/'.$connectionArray['conn_encode']);
        $url = url("//user-connections");
        $notification['user_id'] = $connectionArray['conn_id'];
        $notification['notification_id'] = 1;
        $notification['from_notification'] = $connectionArray['from_id'];
        $notification['conn_notification'] = $connectionArray['conn_id'];
        $notification['is_from_conn'] = 'conn';
        $count = DB::table('front_notifications')->where($notification)->count();
    //   $notification['description'] = $fromUserData['business_category_name'].' '.$fromUserData['sub_category_name'].' this is your payment link -:';
       
       if($urlType == 'accept'){
            $notification['description'] = $fromUserData['business_category_name'].' '.$fromUserData['sub_category_name'].' this is your payment link -:';
            
        $notification['link'] = $url;
        $notification['type'] = 'payment_link';
        }else{
            $notification['description'] = $fromUserData['business_category_name'].' '.$fromUserData['sub_category_name'].' Declined';
        
        $notification['link'] = '';
        $notification['type'] = 'text';
            
        }
        $notification['is_mail'] = true;
        $notification['is_mail_sent'] = false;
        $notification['created_at'] = Carbon::now();
        
        
        if($count == 0){
            DB::table('front_notifications')->insert($notification);
            
        }
        
        return true;
        
        
    }
    
    public function declineConnection(Request $request,$id){
        try{
            if(!Auth::check()){
                return redirect()->to('login');
            }
            
            $decryptString = Crypt::decrypt($id);
            $decrypt = explode(':',$decryptString);
            
            if(count($decrypt) != 3){
                return abort(403);
            }
            
            $connectionArray = DB::table('connections')
                                        ->where('conn_encode',$id)
                                        
                                        ->whereId($decrypt[2])
                                        ->where('status',0)
                                         ->get()->toArray();
            
            if(count($connectionArray) < 1){
                return abort(403);
            }
            $connectionArray = (array) current($connectionArray);
            Self::sendNotification($connectionArray,'declined');
            $timeline = json_decode($connectionArray['timeline'],true);
            $newTimeLine = [];
            $newTimeLine = ['status'=>'Connection Declined','created_at'=>Carbon::now()];
            
            
            array_push($timeline,$newTimeLine);
            
            DB::table('connections')->where('conn_encode',$id)
                                        ->update(['status'=>2]);
                
            return back()->with('message', "You have declined a connection request");
                                          
        }catch (\Exception $e) {
            return $e->getMessage();
        }
            
    }
    
    public function acceptConnection(Request $request,$id,$coupon_discount){
        try{
            if(!Auth::check()){
                return redirect()->to('login');
            }
            
            
            
            $decryptString = Crypt::decrypt($id);
            $decrypt = explode(':',$decryptString);
            
            if(count($decrypt) < 1){
                return abort(403);
            }
            
            
            // check if user is pending
            // $countUser = DB::table('connections')
            //                               ->where($decrypt[0].'_encode',$id)
            //                               ->whereNull($decrypt[0].'_payment_status')
            //                               ->whereId($decrypt[2])
            //                               ->where('status',0)
            //                               ->get()->toArray();
            
            // if(count($countUser) < 1){
            //     return 'Payment Already Done';
            // }
            // // echo count($countUser);exit;
            // $countUser = (array) current($countUser);
            
            // if(Auth::user()->id !=  $countUser[$decrypt[0].'_user_data']){
            //     return abort(403);
            // }
            
            $countUser = DB::table('connections')
                                        //   ->where('from_encode',$id)
                                          ->where('id',$decrypt[2])
                                          ->whereIn('status',[0,1,5,4])
                                        //   ->where('status',0)
                                        //   ->orWhere('status',1)
                                          ->get()->toArray();
            
            
            if(count($countUser) < 1){
                return redirect()->back()->with('message','Error Please Try Again Later');
            }
            $countUser = (array) current($countUser);
            $timeline = json_decode($countUser['timeline'],true);
            
            $newTimeLine = [];
            $newTimeLine = ['status'=>'Connection Approved','created_at'=>Carbon::now()];
            
            array_push($timeline,$newTimeLine);
            
            $msmeType = DB::table('user_data')->whereId($countUser[$decrypt[0].'_user_data'])->value('msme_type');
            
            // $totalAmount = DB::table('charges')->where('name',$msmeType)->value('price');
            $Amount = DB::table('charges')->where('name',$msmeType)->value('price');
            $totalAmount = $Amount - $coupon_discount;
            
            if($countUser[$decrypt[0].'_payment_status'] == false){
                
                if(Auth::user()->id !=  $countUser[$decrypt[0].'_id']){
                    return abort(403);
                }
                
                $orderData = [
                    'receipt'         => 'rcptid_'.Str::random(6),
                    'amount'          => $totalAmount*100, 
                    'currency'        => 'INR',
                    'notes'         => array('encrypted'=>$id)
                ];
                
                $api = new Api(env('RAZORPAY_KEY'), env('RAZORPAY_SECRET'));
                $userData = DB::table('user_data')->select('organization_name','email','contact_no')->where('email',Auth::user()->email)->get()->toArray();
                $userData = current($userData);
                $razorpayOrder = $api->order->create($orderData);
                $razorpayOrder = (array) current($razorpayOrder);
                
                if($countUser['conn_payment_status'] == 1 || $countUser['from_payment_status'] == 1){
                     DB::table('connections')->where('id',$decrypt[2])
                                          ->whereIn('status',[0,1,5,4])
                                          ->update([$decrypt[0].'_razorpay_order_id'=>$razorpayOrder['id']]);
                }else{
                    // exit;
                    DB::table('connections')->where($decrypt[0].'_encode',$id)
                                          ->where('id',$decrypt[2])
                                          ->whereIn('status',[0,1])
                                          ->update([$decrypt[0].'_razorpay_order_id'=>$razorpayOrder['id'],'is_acceptance'=>true,'status'=>1,'timeline'=>json_encode($timeline)]);
                }
                Self::sendNotification($countUser);
                
                
                // DB::table('connections')->where($decrypt[0].'_encode',$id)
                //                           ->where('id',$decrypt[2])
                //                           ->whereIn('status',[0,1])
                //                           ->update([$decrypt[0].'_razorpay_order_id'=>$razorpayOrder['id'],'is_acceptance'=>true,'status'=>1,'timeline'=>json_encode($timeline)]);
                
                
                
                
                
                
                return view('acceptConnection')->with('order_id',$razorpayOrder['id'])->with('userData',$userData);
            }else{
                return redirect()->back()->with('message','Payment already done');
            }
            
        }catch (\Exception $e) {

            return $e->getMessage();
        }
        
        
    }
    
    public function payment(Request $request){
        $razorpayDetails = $request->all();
        $api = new Api(env('RAZORPAY_KEY'), env('RAZORPAY_SECRET'));
        $payment = $api->payment->fetch($razorpayDetails['razorpay_payment_id']);
        $payment = (array) current($payment);
        $status = true;
        
        if(count($payment) >= 1){
            $orderNotes = $payment['notes'];
            $orderNotes = Crypt::decrypt($orderNotes->encrypted);
            $encryptData =  explode(':',$orderNotes);
            $connOrFrom = $encryptData[0];
            $updateData = [];
            $updateData[$connOrFrom.'_razorpay_payment_id'] = $razorpayDetails['razorpay_payment_id'];
            $updateData[$connOrFrom.'_razorpay_signature'] = $razorpayDetails['razorpay_signature'];
        }else{
            $status = false;
        }
        
        
        $orderData = DB::table('connections')->where($connOrFrom.'_razorpay_order_id',$razorpayDetails['razorpay_order_id'])
        
        ->get()->toArray();
        
        $orderData = (array) current($orderData);

        $generated_signature = hash_hmac('sha256',$orderData[$connOrFrom.'_razorpay_order_id']."|".$razorpayDetails['razorpay_payment_id'], env('RAZORPAY_SECRET'));
        
        
        
        if($orderData[$connOrFrom.'_payment_status'] == true){
            echo 'Payemnt Already Done';exit;
        }
        
        if($connOrFrom == "conn"){
            $newTimeLine = [];
            $newTimeLine = ['status'=>'Applicant Payment Done','created_at'=>Carbon::now()];
            if($orderData['from_payment_status'] == true){
                $status = 3;
            }else{
                $status = 5;
            }
        }else{
            $newTimeLine = [];
            $newTimeLine = ['status'=>'Recipent Payment Done','created_at'=>Carbon::now()];
            if($orderData['conn_payment_status'] == true){
                $status = 3;
            }else{
                $status = 4;
            }
        }
        $updateData['status'] = $status;

        
        
        if($generated_signature == $razorpayDetails['razorpay_signature'] && $status){
            $updateData[$connOrFrom.'_payment_status'] = true;
            $updateData['updated_at'] = Carbon::now();
            
            
            $timeline = json_decode($orderData['timeline'],true);
            
            
            
            array_push($timeline,$newTimeLine);
            $updateData['timeline'] = json_encode($timeline);
            
            
            
            $updateData['timeline'] =   json_encode($timeline);
            // echo "<pre>";print_r($updateData);exit;
            
            DB::table('connections')->where($connOrFrom.'_razorpay_order_id',$orderData[$connOrFrom.'_razorpay_order_id'])->update($updateData);
            
            return redirect()->to('/user-connections')->with('message','Payment Successfully Completed');
            
        }else{
            return redirect()->to('/user-connections')->with('message','Payment Not Done');
        }
            
    }
    
    public function checkout($from_id,$msme_type){
        if(!Auth::check()){
            return redirect()->to('login');
        }
        
        $msme_type = base64_decode($msme_type);
        $connectionRequested = DB::table('connections')->select('connections.status','user_data.business_description','connections.from_encode','connections.created_at as connection_created_at','business_category.name as business_category_name','connections.from_id','connections.conn_id','connections.conn_encode')
                                                    ->leftjoin('users','users.id','connections.from_id')
                                                    ->leftjoin('user_data','user_data.email','users.email')
                                                    ->leftjoin('business_category','business_category.id','user_data.business_category')
                                                    ->where('connections.from_id',$from_id)
                                                    ->where('connections.status','1')
                                                    ->get()->first();
        
        // dd($connectionRequested) ; 
        $msme_data_price = DB::table('charges')->select('charges.price','charges.name')
                                        ->where('charges.name', 'like', '%'.$msme_type.'%')
                                        ->get()->first();
        return view('info.checkout')->with('connectionRequest',$connectionRequested)->with('msme_price' ,$msme_data_price);
            
    }
    
    public function checkCoupon(Request $request){
        $coupon_code = $request->coupon;
        $data = Coupons::select('coupons.discount_percentage')->where('coupons.coupon_code',$coupon_code)->where('coupons.status','Active')->first();
        if(isset($data)){
             return response()->json(['code'=> 1, 'result' => $data]);
        }else{
            return response()->json(['code'=>0, 'result' => '']);
        }
       
    }
    

}